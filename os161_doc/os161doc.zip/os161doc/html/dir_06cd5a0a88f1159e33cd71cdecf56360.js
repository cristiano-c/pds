var dir_06cd5a0a88f1159e33cd71cdecf56360 =
[
    [ "kern", "dir_75fa0065d3812c3b24228ee868b9b9e0.html", "dir_75fa0065d3812c3b24228ee868b9b9e0" ],
    [ "current.h", "d9/da8/arch_2mips_2include_2current_8h.html", "d9/da8/arch_2mips_2include_2current_8h" ],
    [ "elf.h", "d2/d2c/arch_2mips_2include_2elf_8h.html", "d2/d2c/arch_2mips_2include_2elf_8h" ],
    [ "membar.h", "db/db0/arch_2mips_2include_2membar_8h.html", "db/db0/arch_2mips_2include_2membar_8h" ],
    [ "specialreg.h", "d0/d6f/specialreg_8h.html", "d0/d6f/specialreg_8h" ],
    [ "spinlock.h", "d2/de8/arch_2mips_2include_2spinlock_8h.html", "d2/de8/arch_2mips_2include_2spinlock_8h" ],
    [ "thread.h", "d5/da1/arch_2mips_2include_2thread_8h.html", "d5/da1/arch_2mips_2include_2thread_8h" ],
    [ "tlb.h", "de/dbb/tlb_8h.html", "de/dbb/tlb_8h" ],
    [ "trapframe.h", "d2/d15/trapframe_8h.html", "d2/d15/trapframe_8h" ],
    [ "types.h", "da/d07/kern_2arch_2mips_2include_2types_8h.html", "da/d07/kern_2arch_2mips_2include_2types_8h" ],
    [ "vm.h", "d1/dea/arch_2mips_2include_2vm_8h.html", "d1/dea/arch_2mips_2include_2vm_8h" ]
];