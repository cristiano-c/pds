var dir_9f42879460ab05a0ca6b1ecad69d618f =
[
    [ "quint.h", "d4/dc2/userland_2include_2test_2quint_8h.html", "d4/dc2/userland_2include_2test_2quint_8h" ],
    [ "triple.h", "d6/da0/userland_2include_2test_2triple_8h.html", "d6/da0/userland_2include_2test_2triple_8h" ]
];