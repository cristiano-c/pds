var dir_b5c982163eea8c4f04b8db523d1237c3 =
[
    [ "triplehuge.c", "db/d13/triplehuge_8c.html", "db/d13/triplehuge_8c" ]
];