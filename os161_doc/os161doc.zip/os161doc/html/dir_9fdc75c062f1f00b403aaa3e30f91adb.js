var dir_9fdc75c062f1f00b403aaa3e30f91adb =
[
    [ "clock.c", "dc/d54/clock_8c.html", "dc/d54/clock_8c" ],
    [ "spinlock.c", "d3/d2d/spinlock_8c.html", "d3/d2d/spinlock_8c" ],
    [ "spl.c", "d7/d2f/spl_8c.html", "d7/d2f/spl_8c" ],
    [ "synch.c", "d1/d0d/synch_8c.html", "d1/d0d/synch_8c" ],
    [ "thread.c", "d3/de7/thread_8c.html", "d3/de7/thread_8c" ],
    [ "threadlist.c", "df/d5e/threadlist_8c.html", "df/d5e/threadlist_8c" ]
];