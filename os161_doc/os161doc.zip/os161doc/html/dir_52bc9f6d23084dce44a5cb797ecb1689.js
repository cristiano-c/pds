var dir_52bc9f6d23084dce44a5cb797ecb1689 =
[
    [ "gcc-millicode", "dir_381f6999042beabbe404a081d153dbe7.html", "dir_381f6999042beabbe404a081d153dbe7" ],
    [ "libc", "dir_673711c88432064fc3e6cde9d0efd0d3.html", "dir_673711c88432064fc3e6cde9d0efd0d3" ]
];