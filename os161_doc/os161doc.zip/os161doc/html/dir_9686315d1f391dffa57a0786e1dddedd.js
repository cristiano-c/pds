var dir_9686315d1f391dffa57a0786e1dddedd =
[
    [ "triplesort.c", "d1/d2b/triplesort_8c.html", "d1/d2b/triplesort_8c" ]
];