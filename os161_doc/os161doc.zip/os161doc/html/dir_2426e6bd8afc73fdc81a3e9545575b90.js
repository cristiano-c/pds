var dir_2426e6bd8afc73fdc81a3e9545575b90 =
[
    [ "loadelf.c", "d5/d26/loadelf_8c.html", "d5/d26/loadelf_8c" ],
    [ "runprogram.c", "de/d6c/runprogram_8c.html", "de/d6c/runprogram_8c" ],
    [ "time_syscalls.c", "d0/d54/time__syscalls_8c.html", "d0/d54/time__syscalls_8c" ]
];