var dir_fe2733a7173ced3b34c617c8a6fbd6d2 =
[
    [ "err.c", "d3/d26/hostcompat_2err_8c.html", null ],
    [ "host-err.h", "da/d75/host-err_8h.html", "da/d75/host-err_8h" ],
    [ "hostcompat.c", "d5/d60/hostcompat_8c.html", "d5/d60/hostcompat_8c" ],
    [ "hostcompat.h", "db/d14/userland_2lib_2hostcompat_2hostcompat_8h.html", "db/d14/userland_2lib_2hostcompat_2hostcompat_8h" ],
    [ "ntohll.c", "db/df0/ntohll_8c.html", null ],
    [ "time.c", "d4/da8/userland_2lib_2hostcompat_2time_8c.html", "d4/da8/userland_2lib_2hostcompat_2time_8c" ]
];