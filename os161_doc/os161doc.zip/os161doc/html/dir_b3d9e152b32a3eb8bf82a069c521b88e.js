var dir_b3d9e152b32a3eb8bf82a069c521b88e =
[
    [ "__puts.c", "d3/d9f/____puts_8c.html", "d3/d9f/____puts_8c" ],
    [ "getchar.c", "d7/dd4/getchar_8c.html", "d7/dd4/getchar_8c" ],
    [ "printf.c", "d1/d3d/printf_8c.html", "d1/d3d/printf_8c" ],
    [ "putchar.c", "db/de0/putchar_8c.html", "db/de0/putchar_8c" ],
    [ "puts.c", "d4/d54/puts_8c.html", "d4/d54/puts_8c" ]
];