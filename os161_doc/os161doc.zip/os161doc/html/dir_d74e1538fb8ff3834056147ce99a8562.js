var dir_d74e1538fb8ff3834056147ce99a8562 =
[
    [ "cdefs.h", "d2/ddb/userland_2include_2sys_2cdefs_8h.html", "d2/ddb/userland_2include_2sys_2cdefs_8h" ],
    [ "endian.h", "d5/dda/userland_2include_2sys_2endian_8h.html", null ],
    [ "ioctl.h", "d4/dc4/userland_2include_2sys_2ioctl_8h.html", null ],
    [ "null.h", "d2/d50/userland_2include_2sys_2null_8h.html", "d2/d50/userland_2include_2sys_2null_8h" ],
    [ "reboot.h", "d5/d8f/userland_2include_2sys_2reboot_8h.html", null ],
    [ "stat.h", "db/da1/userland_2include_2sys_2stat_8h.html", "db/da1/userland_2include_2sys_2stat_8h" ],
    [ "types.h", "d8/d96/userland_2include_2sys_2types_8h.html", "d8/d96/userland_2include_2sys_2types_8h" ],
    [ "wait.h", "da/dd2/userland_2include_2sys_2wait_8h.html", null ]
];