var dir_fd6c07b1429f44fa52539646bb5ead23 =
[
    [ "stdio", "dir_b3d9e152b32a3eb8bf82a069c521b88e.html", "dir_b3d9e152b32a3eb8bf82a069c521b88e" ],
    [ "stdlib", "dir_be0d26af9cb9dac0479ee871396586ca.html", "dir_be0d26af9cb9dac0479ee871396586ca" ],
    [ "string", "dir_b2abd1f9750a7b824335eb91ddb64147.html", "dir_b2abd1f9750a7b824335eb91ddb64147" ],
    [ "time", "dir_fba3b4249adf729a87067b16e1f005ad.html", "dir_fba3b4249adf729a87067b16e1f005ad" ],
    [ "unix", "dir_20fe55c290efeb21fbff089d70075c87.html", "dir_20fe55c290efeb21fbff089d70075c87" ]
];