var dir_010b4c8213b0ff2d6715895278429ede =
[
    [ "main.c", "da/de7/kern_2main_2main_8c.html", "da/de7/kern_2main_2main_8c" ],
    [ "menu.c", "d2/d0a/menu_8c.html", "d2/d0a/menu_8c" ]
];