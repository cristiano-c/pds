var dir_7bda8e2b4a125b797876658f9cb89945 =
[
    [ "sync.c", "db/dc2/sync_8c.html", "db/dc2/sync_8c" ]
];