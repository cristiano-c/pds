var dir_fba3b4249adf729a87067b16e1f005ad =
[
    [ "time.c", "d2/d5d/userland_2lib_2libc_2time_2time_8c.html", "d2/d5d/userland_2lib_2libc_2time_2time_8c" ]
];