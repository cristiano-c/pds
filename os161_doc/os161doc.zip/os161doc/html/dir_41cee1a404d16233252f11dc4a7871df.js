var dir_41cee1a404d16233252f11dc4a7871df =
[
    [ "palin.c", "d1/dac/palin_8c.html", "d1/dac/palin_8c" ]
];