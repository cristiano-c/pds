var dir_543168d510c68d00144f7c31dbdb3476 =
[
    [ "grind.c", "d7/d85/grind_8c.html", "d7/d85/grind_8c" ],
    [ "main.c", "de/d58/userland_2testbin_2schedpong_2main_8c.html", "de/d58/userland_2testbin_2schedpong_2main_8c" ],
    [ "pong.c", "d4/d00/pong_8c.html", "d4/d00/pong_8c" ],
    [ "results.c", "d5/d28/results_8c.html", "d5/d28/results_8c" ],
    [ "results.h", "d7/d4a/results_8h.html", "d7/d4a/results_8h" ],
    [ "tasks.h", "d9/dc0/tasks_8h.html", "d9/dc0/tasks_8h" ],
    [ "think.c", "d3/dc9/think_8c.html", "d3/dc9/think_8c" ],
    [ "usem.c", "dd/d05/usem_8c.html", "dd/d05/usem_8c" ],
    [ "usem.h", "d6/d74/usem_8h.html", "d6/d74/usem_8h" ]
];