var dir_1ca7264f680c9673ecf033ae996beecd =
[
    [ "dumbvm.c", "dc/d69/dumbvm_8c.html", "dc/d69/dumbvm_8c" ],
    [ "ram.c", "dd/d9f/ram_8c.html", "dd/d9f/ram_8c" ]
];