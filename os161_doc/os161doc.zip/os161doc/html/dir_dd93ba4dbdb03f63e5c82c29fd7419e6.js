var dir_dd93ba4dbdb03f63e5c82c29fd7419e6 =
[
    [ "poweroff.c", "d2/ded/poweroff_8c.html", "d2/ded/poweroff_8c" ]
];