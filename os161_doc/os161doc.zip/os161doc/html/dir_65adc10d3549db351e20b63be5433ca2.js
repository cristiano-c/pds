var dir_65adc10d3549db351e20b63be5433ca2 =
[
    [ "syscall.c", "db/dd8/syscall_8c.html", "db/dd8/syscall_8c" ]
];