var dir_7d7d2079a3cdf2043302fa8b2c7a2b11 =
[
    [ "include", "dir_06cd5a0a88f1159e33cd71cdecf56360.html", "dir_06cd5a0a88f1159e33cd71cdecf56360" ],
    [ "locore", "dir_356fd394027503c4cf0483cbc2a1c2f6.html", "dir_356fd394027503c4cf0483cbc2a1c2f6" ],
    [ "syscall", "dir_65adc10d3549db351e20b63be5433ca2.html", "dir_65adc10d3549db351e20b63be5433ca2" ],
    [ "thread", "dir_4c7438117e958f873e3f1920c455c9a9.html", "dir_4c7438117e958f873e3f1920c455c9a9" ],
    [ "vm", "dir_1ca7264f680c9673ecf033ae996beecd.html", "dir_1ca7264f680c9673ecf033ae996beecd" ]
];