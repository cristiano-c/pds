var dir_1987596af144ff04bdaa62db79accda7 =
[
    [ "bus.h", "d4/d9b/bus_8h.html", "d4/d9b/bus_8h" ],
    [ "maxcpus.h", "d0/dae/maxcpus_8h.html", "d0/dae/maxcpus_8h" ]
];