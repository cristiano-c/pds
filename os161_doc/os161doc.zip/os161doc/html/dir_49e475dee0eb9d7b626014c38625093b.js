var dir_49e475dee0eb9d7b626014c38625093b =
[
    [ "endian.h", "da/dd5/kern_2include_2kern_2endian_8h.html", "da/dd5/kern_2include_2kern_2endian_8h" ],
    [ "errmsg.h", "d9/df5/kern_2include_2kern_2errmsg_8h.html", "d9/df5/kern_2include_2kern_2errmsg_8h" ],
    [ "errno.h", "d9/dfc/kern_2include_2kern_2errno_8h.html", "d9/dfc/kern_2include_2kern_2errno_8h" ],
    [ "fcntl.h", "d8/d3e/kern_2include_2kern_2fcntl_8h.html", "d8/d3e/kern_2include_2kern_2fcntl_8h" ],
    [ "ioctl.h", "dc/d60/kern_2include_2kern_2ioctl_8h.html", null ],
    [ "iovec.h", "d1/deb/kern_2include_2kern_2iovec_8h.html", [
      [ "iovec", "db/d79/structiovec.html", "db/d79/structiovec" ]
    ] ],
    [ "limits.h", "da/dd4/kern_2include_2kern_2limits_8h.html", "da/dd4/kern_2include_2kern_2limits_8h" ],
    [ "reboot.h", "d8/daa/kern_2include_2kern_2reboot_8h.html", "d8/daa/kern_2include_2kern_2reboot_8h" ],
    [ "resource.h", "d0/d0c/kern_2include_2kern_2resource_8h.html", "d0/d0c/kern_2include_2kern_2resource_8h" ],
    [ "seek.h", "d3/d72/kern_2include_2kern_2seek_8h.html", "d3/d72/kern_2include_2kern_2seek_8h" ],
    [ "sfs.h", "df/df4/kern_2include_2kern_2sfs_8h.html", "df/df4/kern_2include_2kern_2sfs_8h" ],
    [ "signal.h", "d6/daa/kern_2include_2kern_2signal_8h.html", "d6/daa/kern_2include_2kern_2signal_8h" ],
    [ "socket.h", "d2/dcf/kern_2include_2kern_2socket_8h.html", "d2/dcf/kern_2include_2kern_2socket_8h" ],
    [ "stat.h", "d2/db4/kern_2include_2kern_2stat_8h.html", [
      [ "stat", "da/de7/structstat.html", "da/de7/structstat" ]
    ] ],
    [ "stattypes.h", "d1/dcd/kern_2include_2kern_2stattypes_8h.html", "d1/dcd/kern_2include_2kern_2stattypes_8h" ],
    [ "syscall.h", "d0/dd1/kern_2include_2kern_2syscall_8h.html", "d0/dd1/kern_2include_2kern_2syscall_8h" ],
    [ "time.h", "de/d3b/kern_2include_2kern_2time_8h.html", "de/d3b/kern_2include_2kern_2time_8h" ],
    [ "types.h", "db/d3e/kern_2include_2kern_2types_8h.html", "db/d3e/kern_2include_2kern_2types_8h" ],
    [ "unistd.h", "d4/df9/kern_2include_2kern_2unistd_8h.html", "d4/df9/kern_2include_2kern_2unistd_8h" ],
    [ "wait.h", "d1/d88/kern_2include_2kern_2wait_8h.html", "d1/d88/kern_2include_2kern_2wait_8h" ]
];